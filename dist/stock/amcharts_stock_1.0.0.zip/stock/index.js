/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
webpackJsonp([20],{1004:function(t,e,r){t.exports=r(1005)},1005:function(t,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var n=r(1006);window.am4stock=n},1006:function(t,e,r){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),r.d(e,"StockChart",function(){return s});var n=r(0),o=r(302),s=function(t){function e(){return null!==t&&t.apply(this,arguments)||this}return n.c(e,t),e}(r(206).XYChart);o.registry.registeredClasses.StockChart=s}},[1004]);
//# sourceMappingURL=index.js.map