/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
webpackJsonp([13],{597:function(n,t,a){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var e=a(598);window.am4themes_animated=e.a},598:function(n,t,a){"use strict";var e=a(599);a.d(t,"a",function(){return e.a})},599:function(n,t,a){"use strict";var e=a(117),i=a(56),o=a(107),r=a(91),s=a(90),u=a(250),c=a(173);t.a=function(n){n instanceof e.a&&(n.transitionDuration=400),n instanceof i.a&&(n.rangeChangeDuration=800,n.interpolationDuration=800,n.sequencedInterpolation=!1,n instanceof u.a&&(n.sequencedInterpolation=!0),n instanceof c.a&&(n.sequencedInterpolation=!0)),n instanceof r.a&&(n.animationDuration=400),n instanceof o.a&&(n.animationDuration=800),n instanceof s.a&&(n.defaultState.transitionDuration=800,n.hiddenState.transitionDuration=1e3,n.hiddenState.properties.opacity=1,n.interpolationDuration=1e3)}}},[597]);
//# sourceMappingURL=animated.js.map