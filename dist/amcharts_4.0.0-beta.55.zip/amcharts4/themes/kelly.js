/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
webpackJsonp([8],{627:function(c,e,t){c.exports=t(628)},628:function(c,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var b=t(629);window.am4themes_kelly=b.a},629:function(c,e,t){"use strict";var b=t(630);t.d(e,"a",function(){return b.a})},630:function(c,e,t){"use strict";var b=t(16),j=t(43);e.a=function(c){c instanceof j.a&&(c.list=[Object(b.c)("#F3C300"),Object(b.c)("#875692"),Object(b.c)("#F38400"),Object(b.c)("#A1CAF1"),Object(b.c)("#BE0032"),Object(b.c)("#C2B280"),Object(b.c)("#848482"),Object(b.c)("#008856"),Object(b.c)("#E68FAC"),Object(b.c)("#0067A5"),Object(b.c)("#F99379"),Object(b.c)("#604E97"),Object(b.c)("#F6A600"),Object(b.c)("#B3446C"),Object(b.c)("#DCD300"),Object(b.c)("#882D17"),Object(b.c)("#8DB600"),Object(b.c)("#654522"),Object(b.c)("#E25822"),Object(b.c)("#2B3D26"),Object(b.c)("#F2F3F4"),Object(b.c)("#222222")],c.minLightness=.2,c.maxLightness=.7,c.reuse=!0)}}},[627]);
//# sourceMappingURL=kelly.js.map