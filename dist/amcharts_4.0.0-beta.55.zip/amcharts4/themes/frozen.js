/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
webpackJsonp([9],{623:function(e,c,t){e.exports=t(624)},624:function(e,c,t){"use strict";Object.defineProperty(c,"__esModule",{value:!0});var n=t(625);window.am4themes_frozen=n.a},625:function(e,c,t){"use strict";var n=t(626);t.d(c,"a",function(){return n.a})},626:function(e,c,t){"use strict";var n=t(16),b=t(43);c.a=function(e){e instanceof b.a&&(e.list=[Object(n.c)("#bec4f8"),Object(n.c)("#a5abee"),Object(n.c)("#6a6dde"),Object(n.c)("#4d42cf"),Object(n.c)("#713e8d"),Object(n.c)("#a160a0"),Object(n.c)("#eb6eb0"),Object(n.c)("#f597bb"),Object(n.c)("#fbb8c9"),Object(n.c)("#f8d4d8")],e.minLightness=.2,e.maxLightness=.7,e.reuse=!0)}}},[623]);
//# sourceMappingURL=frozen.js.map