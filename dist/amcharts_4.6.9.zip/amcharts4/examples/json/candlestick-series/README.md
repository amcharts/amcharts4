Steps to use
============

1. Open `index.html` in a browser