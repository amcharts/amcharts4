/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
webpackJsonp([15],{589:function(t,e,c){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var s=c(590);window.am4themes_amcharts=s.a},590:function(t,e,c){"use strict";var s=c(591);c.d(e,"a",function(){return s.a})},591:function(t,e,c){"use strict";var s=c(14),n=c(30),a=c(103);e.a=function(t){t instanceof a.a&&(t.strokeOpacity=.07),t instanceof n.a&&(t.list=[Object(s.c)("#86ce86"),Object(s.c)("#0975da"),Object(s.c)("#0996f2"),Object(s.c)("#1fb0ff"),Object(s.c)("#41baff"),Object(s.c)("#5ec5ff"),Object(s.c)("#3db7ff")],t.reuse=!1,t.stepOptions={lightness:.1,hue:0},t.passOptions={})}}},[589]);
//# sourceMappingURL=amcharts.js.map