/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
am4internal_webpackJsonp(["bec2"],{AZyi:function(e,c,t){"use strict";Object.defineProperty(c,"__esModule",{value:!0});var b=t("8ZqG"),i=t("DHte"),n=function(e){e instanceof i.a&&(e.list=[Object(b.c)("#65738e"),Object(b.c)("#766c91"),Object(b.c)("#78566f"),Object(b.c)("#523b58"),Object(b.c)("#813b3d"),Object(b.c)("#bc5e52"),Object(b.c)("#ee8b78"),Object(b.c)("#f9c885"),Object(b.c)("#eba05c"),Object(b.c)("#9b5134")],e.minLightness=.2,e.maxLightness=.7,e.reuse=!0)};window.am4themes_spiritedaway=n}},["AZyi"]);
//# sourceMappingURL=spiritedaway.js.map