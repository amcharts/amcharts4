/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
am4internal_webpackJsonp(["30f0"],{uvMO:function(e,t,i){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var a=i("01H4"),d=function(e){Object(a.a)(e,"Sprite")&&(e.showSystemTooltip=!1),Object(a.a)(e,"Chart")&&e.padding(0,0,0,0),Object(a.a)(e,"Scrollbar")&&(e.startGrip.disabled=!0,e.endGrip.disabled=!0),(Object(a.a)(e,"AxisLabel")||Object(a.a)(e,"AxisLine")||Object(a.a)(e,"Grid"))&&(e.disabled=!0),Object(a.a)(e,"Axis")&&(e.cursorTooltipEnabled=!1),Object(a.a)(e,"PercentSeries")&&(e.labels.template.disabled=!0,e.ticks.template.disabled=!0),Object(a.a)(e,"ZoomOutButton")&&e.padding(1,1,1,1),Object(a.a)(e,"Container")&&(e.minHeight&&(e.minHeight=void 0),e.minWidth&&(e.minWidth=void 0))};window.am4themes_microchart=d}},["uvMO"]);
//# sourceMappingURL=microchart.js.map