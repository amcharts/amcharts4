/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
am4internal_webpackJsonp(["08fc"],{ubb1:function(t,e,a){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var r=a("01H4"),o=a("W0E6"),n=a("MIZb"),i=function(t){if((Object(r.a)(t,"XYChart")||Object(r.a)(t,"PercentSeries"))&&(t.patterns=new o.a),(Object(r.a)(t,"XYSeries")||Object(r.a)(t,"PercentSeries"))&&t.tooltip){var e=new n.a;t.tooltip.getFillFromObject=!1,t.tooltip.fill=e.getFor("alternativeBackground"),t.tooltip.label.fill=e.getFor("text"),t.tooltip.background.stroke=e.getFor("alternativeBackground")}Object(r.a)(t,"Pattern")&&(t.backgroundOpacity=1)};window.am4themes_patterns=i}},["ubb1"]);
//# sourceMappingURL=patterns.js.map