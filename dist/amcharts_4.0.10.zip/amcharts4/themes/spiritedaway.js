/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
webpackJsonp([6],{624:function(c,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var n=t(625);window.am4themes_spiritedaway=n.a},625:function(c,e,t){"use strict";var n=t(626);t.d(e,"a",function(){return n.a})},626:function(c,e,t){"use strict";var n=t(15),b=t(30);e.a=function(c){c instanceof b.a&&(c.list=[Object(n.c)("#65738e"),Object(n.c)("#766c91"),Object(n.c)("#78566f"),Object(n.c)("#523b58"),Object(n.c)("#813b3d"),Object(n.c)("#bc5e52"),Object(n.c)("#ee8b78"),Object(n.c)("#f9c885"),Object(n.c)("#eba05c"),Object(n.c)("#9b5134")],c.minLightness=.2,c.maxLightness=.7,c.reuse=!0)}}},[624]);
//# sourceMappingURL=spiritedaway.js.map