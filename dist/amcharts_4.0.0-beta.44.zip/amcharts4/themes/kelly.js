/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
webpackJsonp([7],{591:function(c,t,e){c.exports=e(592)},592:function(c,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var b=e(593);window.am4themes_kelly=b.a},593:function(c,t,e){"use strict";var b=e(594);e.d(t,"a",function(){return b.a})},594:function(c,t,e){"use strict";var b=e(19),n=e(65),j=e(110);t.a=function(c){c instanceof n.a&&(c.list=[Object(b.c)("#F3C300"),Object(b.c)("#875692"),Object(b.c)("#F38400"),Object(b.c)("#A1CAF1"),Object(b.c)("#BE0032"),Object(b.c)("#C2B280"),Object(b.c)("#848482"),Object(b.c)("#008856"),Object(b.c)("#E68FAC"),Object(b.c)("#0067A5"),Object(b.c)("#F99379"),Object(b.c)("#604E97"),Object(b.c)("#F6A600"),Object(b.c)("#B3446C"),Object(b.c)("#DCD300"),Object(b.c)("#882D17"),Object(b.c)("#8DB600"),Object(b.c)("#654522"),Object(b.c)("#E25822"),Object(b.c)("#2B3D26"),Object(b.c)("#F2F3F4"),Object(b.c)("#222222")],c.minLightness=.2,c.maxLightness=.7,c.reuse=!0),c instanceof j.a&&(c.urlTarget="_self",c.align="left",c.valign="bottom")}}},[591]);
//# sourceMappingURL=kelly.js.map