/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
webpackJsonp([6],{595:function(c,t,e){c.exports=e(596)},596:function(c,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var n=e(597);window.am4themes_material=n.a},597:function(c,t,e){"use strict";var n=e(598);e.d(t,"a",function(){return n.a})},598:function(c,t,e){"use strict";var n=e(19),a=e(65),o=e(89),i=e(170),r=e(110);t.a=function(c){c instanceof a.a&&(c.list=[Object(n.c)("#F44336"),Object(n.c)("#E91E63"),Object(n.c)("#9C27B0"),Object(n.c)("#673AB7"),Object(n.c)("#3F51B5"),Object(n.c)("#2196F3"),Object(n.c)("#03A9F4"),Object(n.c)("#00BCD4"),Object(n.c)("#009688"),Object(n.c)("#4CAF50"),Object(n.c)("#8BC34A"),Object(n.c)("#CDDC39"),Object(n.c)("#FFEB3B"),Object(n.c)("#FFC107"),Object(n.c)("#FF9800"),Object(n.c)("#FF5722"),Object(n.c)("#795548"),Object(n.c)("#9E9E9E"),Object(n.c)("#607D8B")],c.minLightness=.2,c.maxLightness=.7,c.reuse=!0),c instanceof i.a&&(c.background.cornerRadiusTopLeft=20,c.background.cornerRadiusTopRight=20,c.background.cornerRadiusBottomLeft=20,c.background.cornerRadiusBottomRight=20),c instanceof o.a&&(c.animationDuration=800),c instanceof r.a&&(c.urlTarget="_self",c.align="left",c.valign="bottom")}}},[595]);
//# sourceMappingURL=material.js.map