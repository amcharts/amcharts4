# amCharts 4 Geo Data Changelog

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [4.0.3] - 2018-05-10
### Added
- Added this `CHANGELOG.md`.