/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
am4internal_webpackJsonp(["8ce2"],{ik00:function(e,c,t){"use strict";Object.defineProperty(c,"__esModule",{value:!0});var b=t("8ZqG"),n=t("DHte"),a=function(e){e instanceof n.a&&(e.list=[Object(b.c)("#bec4f8"),Object(b.c)("#a5abee"),Object(b.c)("#6a6dde"),Object(b.c)("#4d42cf"),Object(b.c)("#713e8d"),Object(b.c)("#a160a0"),Object(b.c)("#eb6eb0"),Object(b.c)("#f597bb"),Object(b.c)("#fbb8c9"),Object(b.c)("#f8d4d8")],e.minLightness=.2,e.maxLightness=.7,e.reuse=!0)};window.am4themes_frozen=a}},["ik00"]);
//# sourceMappingURL=frozen.js.map