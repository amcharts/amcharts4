/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
webpackJsonp([11],{601:function(t,e,c){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var n=c(602);window.am4themes_dataviz=n.a},602:function(t,e,c){"use strict";var n=c(603);c.d(e,"a",function(){return n.a})},603:function(t,e,c){"use strict";var n=c(15),s=c(30);e.a=function(t){t instanceof s.a&&(t.list=[Object(n.c)("#283250"),Object(n.c)("#902c2d"),Object(n.c)("#d5433d"),Object(n.c)("#f05440")],t.reuse=!1,t.stepOptions={lightness:.05,hue:0},t.passOptions={})}}},[601]);
//# sourceMappingURL=dataviz.js.map