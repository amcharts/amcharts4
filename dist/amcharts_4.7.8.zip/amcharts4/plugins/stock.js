/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
am4internal_webpackJsonp(["132e"],{"JW+s":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var r={};n.d(r,"StockChart",function(){return i});var s=n("m4/l"),a=n("aCit"),i=function(t){function e(){return null!==t&&t.apply(this,arguments)||this}return s.c(e,t),e}(n("0Mwj").a);a.b.registeredClasses.StockChart=i,window.am4plugins_stock=r}},["JW+s"]);
//# sourceMappingURL=stock.js.map