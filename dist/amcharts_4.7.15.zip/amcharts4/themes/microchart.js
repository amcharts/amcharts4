/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
am4internal_webpackJsonp(["30f0"],{uvMO:function(i,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var s=t("Mtpk"),d=function(i){Object(s.is)(i,"Sprite")&&(i.showSystemTooltip=!1),Object(s.is)(i,"Chart")&&i.padding(0,0,0,0),Object(s.is)(i,"Scrollbar")&&(i.startGrip.disabled=!0,i.endGrip.disabled=!0),(Object(s.is)(i,"AxisLabel")||Object(s.is)(i,"AxisLine")||Object(s.is)(i,"Grid"))&&(i.disabled=!0),Object(s.is)(i,"Axis")&&(i.cursorTooltipEnabled=!1),Object(s.is)(i,"PercentSeries")&&(i.labels.template.disabled=!0,i.ticks.template.disabled=!0),Object(s.is)(i,"ZoomOutButton")&&i.padding(1,1,1,1),Object(s.is)(i,"Container")&&(i.minHeight&&(i.minHeight=void 0),i.minWidth&&(i.minWidth=void 0))};window.am4themes_microchart=d}},["uvMO"]);
//# sourceMappingURL=microchart.js.map